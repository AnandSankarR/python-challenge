
# WeatherPy



```python
import json
import requests as req
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from citipy import citipy
import openweathermapy.core as ow
```


```python
# Get random geo-coordinates 
lats = np.random.uniform(-90,90,1500)
longs = np.random.uniform(-180,180,1500)
zip_coord_cities = zip(lats, longs)

```


```python
# Use citypy library for nearby cities
cities = []
for coordinate_pair in zip_coord_cities:
   lat, lon = coordinate_pair
   #city = citipy.nearest_city(lat, lon).city_name
   city = citipy.nearest_city(lat, lon)
   if city not in cities:
       cities.append(city)
print(len(cities))
```

    619
    


```python
# Create a dataframe for the cities list
cities_df = pd.DataFrame(cities)
```


```python
# Get city name and corresponding country code
cities_name=[]
countrycode=[]
for city in cities:
    country = city.country_code
    name = city.city_name
    cities_name.append(name)
    countrycode.append(country)

cities_df['City']=cities_name
cities_df['Country']=countrycode
cities_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>City</th>
      <th>Country</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>&lt;citipy.citipy.City object at 0x000002075FF7CBE0&gt;</td>
      <td>qaanaaq</td>
      <td>gl</td>
    </tr>
    <tr>
      <th>1</th>
      <td>&lt;citipy.citipy.City object at 0x0000020760680400&gt;</td>
      <td>taoudenni</td>
      <td>ml</td>
    </tr>
    <tr>
      <th>2</th>
      <td>&lt;citipy.citipy.City object at 0x00000207615B3390&gt;</td>
      <td>richards bay</td>
      <td>za</td>
    </tr>
    <tr>
      <th>3</th>
      <td>&lt;citipy.citipy.City object at 0x00000207615A0FD0&gt;</td>
      <td>bredasdorp</td>
      <td>za</td>
    </tr>
    <tr>
      <th>4</th>
      <td>&lt;citipy.citipy.City object at 0x000002075FA45128&gt;</td>
      <td>liniere</td>
      <td>ca</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Drop duplicate cities in 'City'
cities_df = cities_df.drop_duplicates("City")
cities_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>City</th>
      <th>Country</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>&lt;citipy.citipy.City object at 0x000002075FF7CBE0&gt;</td>
      <td>qaanaaq</td>
      <td>gl</td>
    </tr>
    <tr>
      <th>1</th>
      <td>&lt;citipy.citipy.City object at 0x0000020760680400&gt;</td>
      <td>taoudenni</td>
      <td>ml</td>
    </tr>
    <tr>
      <th>2</th>
      <td>&lt;citipy.citipy.City object at 0x00000207615B3390&gt;</td>
      <td>richards bay</td>
      <td>za</td>
    </tr>
    <tr>
      <th>3</th>
      <td>&lt;citipy.citipy.City object at 0x00000207615A0FD0&gt;</td>
      <td>bredasdorp</td>
      <td>za</td>
    </tr>
    <tr>
      <th>4</th>
      <td>&lt;citipy.citipy.City object at 0x000002075FA45128&gt;</td>
      <td>liniere</td>
      <td>ca</td>
    </tr>
  </tbody>
</table>
</div>




```python
api_key=""
cities_df["Latitude"] =""
cities_df["Temperature"] =""
cities_df["Humidity"] = ""
cities_df["Cloud Cover"] = ""
cities_df["Wind Speed"] = ""
cities_df["Date"] =""
cities_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>City</th>
      <th>Country</th>
      <th>Latitude</th>
      <th>Temperature</th>
      <th>Humidity</th>
      <th>Cloud Cover</th>
      <th>Wind Speed</th>
      <th>Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>&lt;citipy.citipy.City object at 0x000002075FF7CBE0&gt;</td>
      <td>qaanaaq</td>
      <td>gl</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>1</th>
      <td>&lt;citipy.citipy.City object at 0x0000020760680400&gt;</td>
      <td>taoudenni</td>
      <td>ml</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>2</th>
      <td>&lt;citipy.citipy.City object at 0x00000207615B3390&gt;</td>
      <td>richards bay</td>
      <td>za</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>3</th>
      <td>&lt;citipy.citipy.City object at 0x00000207615A0FD0&gt;</td>
      <td>bredasdorp</td>
      <td>za</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>4</th>
      <td>&lt;citipy.citipy.City object at 0x000002075FA45128&gt;</td>
      <td>liniere</td>
      <td>ca</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  </tbody>
</table>
</div>




```python
print(len(cities))
```

    619
    


```python
# Get api-key for openweathermap current weather api
api_key = "8f1b9cd4a84af0404d4d40da7aa2636c"

# Loop through cities dataframe and run a weather search for each city
for index, row in cities_df.iterrows():
        url="http://api.openweathermap.org/data/2.5/weather?q=%s&units=IMPERIAL&mode=json&APPID=%s" % (row["City"].replace(" ","+"), api_key)
        weather = req.get(url).json()
        try:
            cities_df.set_value(index, "Temperature", weather["main"]["temp"])
            cities_df.set_value(index, "Humidity", weather["main"]["humidity"])
            cities_df.set_value(index, "Cloud Cover", weather["clouds"]["all"])
            cities_df.set_value(index, "Wind Speed", weather["wind"]["speed"])
            cities_df.set_value(index, "Date", weather["dt"])
            cities_df.set_value(index, "Latitude", weather["coord"]["lat"])  
            
            print("City id: " + str(weather['id']) + " and City name: " + weather['name'])
            print(url) 
        
        except:
            print("Missing data. Skipping!!!")
               
        #weather_data.append(req.get(url).json())
#print(weather_data[0])

# Replace whitespaces in columns with NaN
# cities_df.replace(r'', np.NaN)  

# cities_df = cities_df.drop('0', 1)

# Remove all rows with NaN entries
#cities_df.dropna(how='any') 

# Fill NaN entries with 0

cities_df.fillna(0).head()
```

    City id: 3831208 and City name: Qaanaaq
    http://api.openweathermap.org/data/2.5/weather?q=qaanaaq&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2450173 and City name: Taoudenni
    http://api.openweathermap.org/data/2.5/weather?q=taoudenni&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 962367 and City name: Richards Bay
    http://api.openweathermap.org/data/2.5/weather?q=richards+bay&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1015776 and City name: Bredasdorp
    http://api.openweathermap.org/data/2.5/weather?q=bredasdorp&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 3443341 and City name: Carmelo
    http://api.openweathermap.org/data/2.5/weather?q=carmelo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 371745 and City name: Kutum
    http://api.openweathermap.org/data/2.5/weather?q=kutum&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3583102 and City name: San Julian
    http://api.openweathermap.org/data/2.5/weather?q=san+julian&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3833859 and City name: Barrow
    http://api.openweathermap.org/data/2.5/weather?q=barrow&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2621448 and City name: Give
    http://api.openweathermap.org/data/2.5/weather?q=give&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5972762 and City name: Hay River
    http://api.openweathermap.org/data/2.5/weather?q=hay+river&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3378644 and City name: Georgetown
    http://api.openweathermap.org/data/2.5/weather?q=georgetown&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3833367 and City name: Ushuaia
    http://api.openweathermap.org/data/2.5/weather?q=ushuaia&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1278715 and City name: Amreli
    http://api.openweathermap.org/data/2.5/weather?q=amreli&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3357247 and City name: Gobabis
    http://api.openweathermap.org/data/2.5/weather?q=gobabis&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2126199 and City name: Cherskiy
    http://api.openweathermap.org/data/2.5/weather?q=cherskiy&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3874787 and City name: Punta Arenas
    http://api.openweathermap.org/data/2.5/weather?q=punta+arenas&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2012532 and City name: Zhigalovo
    http://api.openweathermap.org/data/2.5/weather?q=zhigalovo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2034834 and City name: Shuangcheng
    http://api.openweathermap.org/data/2.5/weather?q=shuangcheng&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5106834 and City name: Albany
    http://api.openweathermap.org/data/2.5/weather?q=albany&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2412992 and City name: Kerewan
    http://api.openweathermap.org/data/2.5/weather?q=kerewan&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5848280 and City name: Kapaa
    http://api.openweathermap.org/data/2.5/weather?q=kapaa&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 262462 and City name: Saint George
    http://api.openweathermap.org/data/2.5/weather?q=saint+george&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1628757 and City name: Maloy
    http://api.openweathermap.org/data/2.5/weather?q=maloy&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 290030 and City name: Doha
    http://api.openweathermap.org/data/2.5/weather?q=doha&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2126123 and City name: Chokurdakh
    http://api.openweathermap.org/data/2.5/weather?q=chokurdakh&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 3453158 and City name: Pontalina
    http://api.openweathermap.org/data/2.5/weather?q=pontalina&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4030556 and City name: Rikitea
    http://api.openweathermap.org/data/2.5/weather?q=rikitea&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3366880 and City name: Hermanus
    http://api.openweathermap.org/data/2.5/weather?q=hermanus&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3720824 and City name: Miragoane
    http://api.openweathermap.org/data/2.5/weather?q=miragoane&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1282666 and City name: Tikapur
    http://api.openweathermap.org/data/2.5/weather?q=tikapur&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6185377 and City name: Yellowknife
    http://api.openweathermap.org/data/2.5/weather?q=yellowknife&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2175403 and City name: Bluff
    http://api.openweathermap.org/data/2.5/weather?q=bluff&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1273574 and City name: Vaini
    http://api.openweathermap.org/data/2.5/weather?q=vaini&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2155415 and City name: New Norfolk
    http://api.openweathermap.org/data/2.5/weather?q=new+norfolk&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2122090 and City name: Pevek
    http://api.openweathermap.org/data/2.5/weather?q=pevek&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2181625 and City name: Te Anau
    http://api.openweathermap.org/data/2.5/weather?q=te+anau&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3896218 and City name: Castro
    http://api.openweathermap.org/data/2.5/weather?q=castro&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2966778 and City name: Ballina
    http://api.openweathermap.org/data/2.5/weather?q=ballina&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5855927 and City name: Hilo
    http://api.openweathermap.org/data/2.5/weather?q=hilo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 933182 and City name: Palapye
    http://api.openweathermap.org/data/2.5/weather?q=palapye&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1267390 and City name: Kavaratti
    http://api.openweathermap.org/data/2.5/weather?q=kavaratti&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6542153 and City name: Arezzo
    http://api.openweathermap.org/data/2.5/weather?q=arezzo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1259091 and City name: Kollam
    http://api.openweathermap.org/data/2.5/weather?q=kollam&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3471451 and City name: Arraial do Cabo
    http://api.openweathermap.org/data/2.5/weather?q=arraial+do+cabo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 439101 and City name: Aysha
    http://api.openweathermap.org/data/2.5/weather?q=aysha&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 3372707 and City name: Ribeira Grande
    http://api.openweathermap.org/data/2.5/weather?q=ribeira+grande&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2126018 and City name: De-Kastri
    http://api.openweathermap.org/data/2.5/weather?q=de-kastri&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3369157 and City name: Cape Town
    http://api.openweathermap.org/data/2.5/weather?q=cape+town&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3037253 and City name: Arcachon
    http://api.openweathermap.org/data/2.5/weather?q=arcachon&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4407665 and City name: Kodiak
    http://api.openweathermap.org/data/2.5/weather?q=kodiak&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3418910 and City name: Upernavik
    http://api.openweathermap.org/data/2.5/weather?q=upernavik&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1282256 and City name: Hithadhoo
    http://api.openweathermap.org/data/2.5/weather?q=hithadhoo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3899539 and City name: Antofagasta
    http://api.openweathermap.org/data/2.5/weather?q=antofagasta&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2110227 and City name: Butaritari
    http://api.openweathermap.org/data/2.5/weather?q=butaritari&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1490256 and City name: Talnakh
    http://api.openweathermap.org/data/2.5/weather?q=talnakh&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2163355 and City name: Hobart
    http://api.openweathermap.org/data/2.5/weather?q=hobart&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1519422 and City name: Semey
    http://api.openweathermap.org/data/2.5/weather?q=semey&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5959803 and City name: Capreol
    http://api.openweathermap.org/data/2.5/weather?q=capreol&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4333811 and City name: Morgan City
    http://api.openweathermap.org/data/2.5/weather?q=morgan+city&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4501427 and City name: Port Elizabeth
    http://api.openweathermap.org/data/2.5/weather?q=port+elizabeth&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3652764 and City name: Puerto Ayora
    http://api.openweathermap.org/data/2.5/weather?q=puerto+ayora&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3974771 and City name: Praxedis Guerrero
    http://api.openweathermap.org/data/2.5/weather?q=praxedis+guerrero&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6138908 and City name: Saint-Philippe
    http://api.openweathermap.org/data/2.5/weather?q=saint-philippe&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3654870 and City name: Santa Ines
    http://api.openweathermap.org/data/2.5/weather?q=santa+ines&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2208248 and City name: Kaitangata
    http://api.openweathermap.org/data/2.5/weather?q=kaitangata&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4951594 and City name: Southbridge
    http://api.openweathermap.org/data/2.5/weather?q=southbridge&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4031574 and City name: Provideniya
    http://api.openweathermap.org/data/2.5/weather?q=provideniya&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2239862 and City name: Malanje
    http://api.openweathermap.org/data/2.5/weather?q=malanje&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6533368 and City name: Moranbah
    http://api.openweathermap.org/data/2.5/weather?q=moranbah&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2156643 and City name: Mount Gambier
    http://api.openweathermap.org/data/2.5/weather?q=mount+gambier&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1734651 and City name: Gua Musang
    http://api.openweathermap.org/data/2.5/weather?q=gua+musang&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2075265 and City name: Busselton
    http://api.openweathermap.org/data/2.5/weather?q=busselton&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5386035 and City name: Rancho Palos Verdes
    http://api.openweathermap.org/data/2.5/weather?q=rancho+palos+verdes&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2960970 and City name: Westport
    http://api.openweathermap.org/data/2.5/weather?q=westport&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 546105 and City name: Nikolskoye
    http://api.openweathermap.org/data/2.5/weather?q=nikolskoye&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3421982 and City name: Maniitsoq
    http://api.openweathermap.org/data/2.5/weather?q=maniitsoq&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1714733 and City name: Dingle
    http://api.openweathermap.org/data/2.5/weather?q=dingle&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2729907 and City name: Longyearbyen
    http://api.openweathermap.org/data/2.5/weather?q=longyearbyen&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2069194 and City name: Jamestown
    http://api.openweathermap.org/data/2.5/weather?q=jamestown&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1006984 and City name: East London
    http://api.openweathermap.org/data/2.5/weather?q=east+london&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1733782 and City name: Victoria
    http://api.openweathermap.org/data/2.5/weather?q=victoria&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3424607 and City name: Tasiilaq
    http://api.openweathermap.org/data/2.5/weather?q=tasiilaq&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6167817 and City name: Torbay
    http://api.openweathermap.org/data/2.5/weather?q=torbay&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 245669 and City name: Adre
    http://api.openweathermap.org/data/2.5/weather?q=adre&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 506320 and City name: Poputnaya
    http://api.openweathermap.org/data/2.5/weather?q=poputnaya&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3374083 and City name: Bathsheba
    http://api.openweathermap.org/data/2.5/weather?q=bathsheba&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5954718 and City name: Flin Flon
    http://api.openweathermap.org/data/2.5/weather?q=flin+flon&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 64814 and City name: Bandarbeyla
    http://api.openweathermap.org/data/2.5/weather?q=bandarbeyla&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2094342 and City name: Kavieng
    http://api.openweathermap.org/data/2.5/weather?q=kavieng&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2396853 and City name: Omboue
    http://api.openweathermap.org/data/2.5/weather?q=omboue&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2112802 and City name: Hasaki
    http://api.openweathermap.org/data/2.5/weather?q=hasaki&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 986717 and City name: Kruisfontein
    http://api.openweathermap.org/data/2.5/weather?q=kruisfontein&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4944903 and City name: Nantucket
    http://api.openweathermap.org/data/2.5/weather?q=nantucket&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 562161 and City name: Galich
    http://api.openweathermap.org/data/2.5/weather?q=galich&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4035715 and City name: Avarua
    http://api.openweathermap.org/data/2.5/weather?q=avarua&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1507390 and City name: Dikson
    http://api.openweathermap.org/data/2.5/weather?q=dikson&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4696233 and City name: Harlingen
    http://api.openweathermap.org/data/2.5/weather?q=harlingen&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5226534 and City name: Brookings
    http://api.openweathermap.org/data/2.5/weather?q=brookings&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3354077 and City name: Opuwo
    http://api.openweathermap.org/data/2.5/weather?q=opuwo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1491977 and City name: Shumskiy
    http://api.openweathermap.org/data/2.5/weather?q=shumskiy&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5924351 and City name: Clyde River
    http://api.openweathermap.org/data/2.5/weather?q=clyde+river&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3863379 and City name: Mar del Plata
    http://api.openweathermap.org/data/2.5/weather?q=mar+del+plata&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2444219 and City name: Goure
    http://api.openweathermap.org/data/2.5/weather?q=goure&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2145554 and City name: Ulladulla
    http://api.openweathermap.org/data/2.5/weather?q=ulladulla&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1701054 and City name: Marawi
    http://api.openweathermap.org/data/2.5/weather?q=marawi&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3868633 and City name: Vallenar
    http://api.openweathermap.org/data/2.5/weather?q=vallenar&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2656067 and City name: Broome
    http://api.openweathermap.org/data/2.5/weather?q=broome&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3496831 and City name: Mao
    http://api.openweathermap.org/data/2.5/weather?q=mao&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1273294 and City name: Dwarka
    http://api.openweathermap.org/data/2.5/weather?q=dwarka&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3996234 and City name: Lazaro Cardenas
    http://api.openweathermap.org/data/2.5/weather?q=lazaro+cardenas&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2517679 and City name: Fortuna
    http://api.openweathermap.org/data/2.5/weather?q=fortuna&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 964432 and City name: Port Alfred
    http://api.openweathermap.org/data/2.5/weather?q=port+alfred&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4198322 and City name: Griffin
    http://api.openweathermap.org/data/2.5/weather?q=griffin&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2120048 and City name: Ust-Nera
    http://api.openweathermap.org/data/2.5/weather?q=ust-nera&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4020109 and City name: Atuona
    http://api.openweathermap.org/data/2.5/weather?q=atuona&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3412093 and City name: Vestmannaeyjar
    http://api.openweathermap.org/data/2.5/weather?q=vestmannaeyjar&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4033557 and City name: Tautira
    http://api.openweathermap.org/data/2.5/weather?q=tautira&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3416888 and City name: Grindavik
    http://api.openweathermap.org/data/2.5/weather?q=grindavik&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 6201424 and City name: Mataura
    http://api.openweathermap.org/data/2.5/weather?q=mataura&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5380437 and City name: Pacific Grove
    http://api.openweathermap.org/data/2.5/weather?q=pacific+grove&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1254046 and City name: Tura
    http://api.openweathermap.org/data/2.5/weather?q=tura&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 1793910 and City name: Dongli
    http://api.openweathermap.org/data/2.5/weather?q=dongli&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    Missing data. Skipping!!!
    City id: 127319 and City name: Khorramshahr
    http://api.openweathermap.org/data/2.5/weather?q=khorramshahr&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 110690 and City name: Faya
    http://api.openweathermap.org/data/2.5/weather?q=faya&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1014034 and City name: Carnarvon
    http://api.openweathermap.org/data/2.5/weather?q=carnarvon&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 286621 and City name: Salalah
    http://api.openweathermap.org/data/2.5/weather?q=salalah&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 712682 and City name: Bekhtery
    http://api.openweathermap.org/data/2.5/weather?q=bekhtery&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1847947 and City name: Shingu
    http://api.openweathermap.org/data/2.5/weather?q=shingu&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3374210 and City name: Sao Filipe
    http://api.openweathermap.org/data/2.5/weather?q=sao+filipe&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 287286 and City name: Muscat
    http://api.openweathermap.org/data/2.5/weather?q=muscat&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 780687 and City name: Berlevag
    http://api.openweathermap.org/data/2.5/weather?q=berlevag&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5367788 and City name: Lompoc
    http://api.openweathermap.org/data/2.5/weather?q=lompoc&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 1337606 and City name: Eydhafushi
    http://api.openweathermap.org/data/2.5/weather?q=eydhafushi&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 556268 and City name: Ostrovnoy
    http://api.openweathermap.org/data/2.5/weather?q=ostrovnoy&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2344415 and City name: Duku
    http://api.openweathermap.org/data/2.5/weather?q=duku&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 1280037 and City name: Shache
    http://api.openweathermap.org/data/2.5/weather?q=shache&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5859699 and City name: College
    http://api.openweathermap.org/data/2.5/weather?q=college&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1274116 and City name: Chipurupalle
    http://api.openweathermap.org/data/2.5/weather?q=chipurupalle&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 727030 and City name: Milkovo
    http://api.openweathermap.org/data/2.5/weather?q=milkovo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6165406 and City name: Thompson
    http://api.openweathermap.org/data/2.5/weather?q=thompson&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3631878 and City name: Moron
    http://api.openweathermap.org/data/2.5/weather?q=moron&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 146639 and City name: Lasa
    http://api.openweathermap.org/data/2.5/weather?q=lasa&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2164422 and City name: Griffith
    http://api.openweathermap.org/data/2.5/weather?q=griffith&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1263942 and City name: Manavalakurichi
    http://api.openweathermap.org/data/2.5/weather?q=manavalakurichi&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 3689325 and City name: Mutis
    http://api.openweathermap.org/data/2.5/weather?q=mutis&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6536873 and City name: Gualdo Tadino
    http://api.openweathermap.org/data/2.5/weather?q=gualdo+tadino&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 4011743 and City name: Constitucion
    http://api.openweathermap.org/data/2.5/weather?q=constitucion&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1214488 and City name: Meulaboh
    http://api.openweathermap.org/data/2.5/weather?q=meulaboh&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3899695 and City name: Ancud
    http://api.openweathermap.org/data/2.5/weather?q=ancud&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1637001 and City name: Biak
    http://api.openweathermap.org/data/2.5/weather?q=biak&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1786657 and City name: Yinchuan
    http://api.openweathermap.org/data/2.5/weather?q=yinchuan&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3423146 and City name: Ilulissat
    http://api.openweathermap.org/data/2.5/weather?q=ilulissat&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2141305 and City name: Fayaoue
    http://api.openweathermap.org/data/2.5/weather?q=fayaoue&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2022572 and City name: Khatanga
    http://api.openweathermap.org/data/2.5/weather?q=khatanga&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5919850 and City name: Chapais
    http://api.openweathermap.org/data/2.5/weather?q=chapais&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 884927 and City name: Mutoko
    http://api.openweathermap.org/data/2.5/weather?q=mutoko&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3672086 and City name: Pizarro
    http://api.openweathermap.org/data/2.5/weather?q=pizarro&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2034440 and City name: Tieli
    http://api.openweathermap.org/data/2.5/weather?q=tieli&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2180815 and City name: Tuatapere
    http://api.openweathermap.org/data/2.5/weather?q=tuatapere&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2014078 and City name: Urusha
    http://api.openweathermap.org/data/2.5/weather?q=urusha&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3220813 and City name: Wanning
    http://api.openweathermap.org/data/2.5/weather?q=wanning&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3839307 and City name: Rawson
    http://api.openweathermap.org/data/2.5/weather?q=rawson&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2122605 and City name: Okhotsk
    http://api.openweathermap.org/data/2.5/weather?q=okhotsk&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3465342 and City name: Puerto Quijarro
    http://api.openweathermap.org/data/2.5/weather?q=puerto+quijarro&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3939168 and City name: Huarmey
    http://api.openweathermap.org/data/2.5/weather?q=huarmey&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1503726 and City name: Kharp
    http://api.openweathermap.org/data/2.5/weather?q=kharp&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 898947 and City name: Senanga
    http://api.openweathermap.org/data/2.5/weather?q=senanga&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2017155 and City name: Saskylakh
    http://api.openweathermap.org/data/2.5/weather?q=saskylakh&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 72181 and City name: Marzuq
    http://api.openweathermap.org/data/2.5/weather?q=marzuq&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 336454 and City name: Ginir
    http://api.openweathermap.org/data/2.5/weather?q=ginir&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3456642 and City name: Mozarlandia
    http://api.openweathermap.org/data/2.5/weather?q=mozarlandia&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5955902 and City name: Fort Nelson
    http://api.openweathermap.org/data/2.5/weather?q=fort+nelson&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 287286 and City name: Ruwi
    http://api.openweathermap.org/data/2.5/weather?q=ruwi&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 463355 and City name: Zheleznodorozhnyy
    http://api.openweathermap.org/data/2.5/weather?q=zheleznodorozhnyy&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 934322 and City name: Mahebourg
    http://api.openweathermap.org/data/2.5/weather?q=mahebourg&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2121385 and City name: Severo-Kurilsk
    http://api.openweathermap.org/data/2.5/weather?q=severo-kurilsk&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1633419 and City name: Padang
    http://api.openweathermap.org/data/2.5/weather?q=padang&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4815462 and City name: Moundsville
    http://api.openweathermap.org/data/2.5/weather?q=moundsville&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2270385 and City name: Camacha
    http://api.openweathermap.org/data/2.5/weather?q=camacha&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1865309 and City name: Katsuura
    http://api.openweathermap.org/data/2.5/weather?q=katsuura&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5767918 and City name: Pierre
    http://api.openweathermap.org/data/2.5/weather?q=pierre&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3421765 and City name: Nanortalik
    http://api.openweathermap.org/data/2.5/weather?q=nanortalik&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 7626384 and City name: Hovd
    http://api.openweathermap.org/data/2.5/weather?q=hovd&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3573374 and City name: The Valley
    http://api.openweathermap.org/data/2.5/weather?q=the+valley&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2145875 and City name: Tumut
    http://api.openweathermap.org/data/2.5/weather?q=tumut&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5871146 and City name: Palmer
    http://api.openweathermap.org/data/2.5/weather?q=palmer&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2214827 and City name: Mizdah
    http://api.openweathermap.org/data/2.5/weather?q=mizdah&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6170031 and City name: Tuktoyaktuk
    http://api.openweathermap.org/data/2.5/weather?q=tuktoyaktuk&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2381334 and City name: Atar
    http://api.openweathermap.org/data/2.5/weather?q=atar&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 933734 and City name: Gweta
    http://api.openweathermap.org/data/2.5/weather?q=gweta&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5921525 and City name: Mackay
    http://api.openweathermap.org/data/2.5/weather?q=mackay&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 3674292 and City name: Mosquera
    http://api.openweathermap.org/data/2.5/weather?q=mosquera&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 3139597 and City name: Sistranda
    http://api.openweathermap.org/data/2.5/weather?q=sistranda&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5301067 and City name: Kingman
    http://api.openweathermap.org/data/2.5/weather?q=kingman&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1529651 and City name: Altay
    http://api.openweathermap.org/data/2.5/weather?q=altay&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4036284 and City name: Alofi
    http://api.openweathermap.org/data/2.5/weather?q=alofi&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5880568 and City name: Bethel
    http://api.openweathermap.org/data/2.5/weather?q=bethel&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5905393 and City name: Bonavista
    http://api.openweathermap.org/data/2.5/weather?q=bonavista&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 726524 and City name: Svoge
    http://api.openweathermap.org/data/2.5/weather?q=svoge&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3567834 and City name: Baracoa
    http://api.openweathermap.org/data/2.5/weather?q=baracoa&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3573739 and City name: Esperance
    http://api.openweathermap.org/data/2.5/weather?q=esperance&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2185329 and City name: Waipawa
    http://api.openweathermap.org/data/2.5/weather?q=waipawa&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1298911 and City name: Pyu
    http://api.openweathermap.org/data/2.5/weather?q=pyu&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 1804979 and City name: Juegang
    http://api.openweathermap.org/data/2.5/weather?q=juegang&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 480884 and City name: Tsilna
    http://api.openweathermap.org/data/2.5/weather?q=tsilna&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 1651810 and City name: Airai
    http://api.openweathermap.org/data/2.5/weather?q=airai&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3026644 and City name: Souillac
    http://api.openweathermap.org/data/2.5/weather?q=souillac&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1641899 and City name: Labuhan
    http://api.openweathermap.org/data/2.5/weather?q=labuhan&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 3464100 and City name: Entre Rios
    http://api.openweathermap.org/data/2.5/weather?q=entre+rios&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 897456 and City name: Sinazongwe
    http://api.openweathermap.org/data/2.5/weather?q=sinazongwe&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2128558 and City name: Otofuke
    http://api.openweathermap.org/data/2.5/weather?q=otofuke&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2995603 and City name: Saint-Pierre
    http://api.openweathermap.org/data/2.5/weather?q=saint-pierre&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2112444 and City name: Kamaishi
    http://api.openweathermap.org/data/2.5/weather?q=kamaishi&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1650213 and City name: Banjarmasin
    http://api.openweathermap.org/data/2.5/weather?q=banjarmasin&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1631905 and City name: Payakumbuh
    http://api.openweathermap.org/data/2.5/weather?q=payakumbuh&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2136825 and City name: Isangel
    http://api.openweathermap.org/data/2.5/weather?q=isangel&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1229989 and City name: Point Pedro
    http://api.openweathermap.org/data/2.5/weather?q=point+pedro&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 934479 and City name: Grand Gaube
    http://api.openweathermap.org/data/2.5/weather?q=grand+gaube&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3382160 and City name: Cayenne
    http://api.openweathermap.org/data/2.5/weather?q=cayenne&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    Missing data. Skipping!!!
    Missing data. Skipping!!!
    City id: 3428576 and City name: San Pedro
    http://api.openweathermap.org/data/2.5/weather?q=san+pedro&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 1262574 and City name: Mul
    http://api.openweathermap.org/data/2.5/weather?q=mul&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 3588206 and City name: Tucuru
    http://api.openweathermap.org/data/2.5/weather?q=tucuru&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3985710 and City name: Cabo San Lucas
    http://api.openweathermap.org/data/2.5/weather?q=cabo+san+lucas&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3162970 and City name: Ardalstangen
    http://api.openweathermap.org/data/2.5/weather?q=ardalstangen&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 643453 and City name: Sola
    http://api.openweathermap.org/data/2.5/weather?q=sola&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1279307 and City name: Afzalgarh
    http://api.openweathermap.org/data/2.5/weather?q=afzalgarh&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 533933 and City name: Lovozero
    http://api.openweathermap.org/data/2.5/weather?q=lovozero&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5864145 and City name: Homer
    http://api.openweathermap.org/data/2.5/weather?q=homer&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5847411 and City name: Kahului
    http://api.openweathermap.org/data/2.5/weather?q=kahului&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3893629 and City name: Coquimbo
    http://api.openweathermap.org/data/2.5/weather?q=coquimbo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6112608 and City name: Powell River
    http://api.openweathermap.org/data/2.5/weather?q=powell+river&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2013639 and City name: Verkhnevilyuysk
    http://api.openweathermap.org/data/2.5/weather?q=verkhnevilyuysk&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2015306 and City name: Tiksi
    http://api.openweathermap.org/data/2.5/weather?q=tiksi&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3448903 and City name: Sao Joao da Barra
    http://api.openweathermap.org/data/2.5/weather?q=sao+joao+da+barra&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1263776 and City name: Mangan
    http://api.openweathermap.org/data/2.5/weather?q=mangan&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2630299 and City name: Hofn
    http://api.openweathermap.org/data/2.5/weather?q=hofn&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3860443 and City name: Comodoro Rivadavia
    http://api.openweathermap.org/data/2.5/weather?q=comodoro+rivadavia&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2212775 and City name: Sabha
    http://api.openweathermap.org/data/2.5/weather?q=sabha&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1635283 and City name: Metro
    http://api.openweathermap.org/data/2.5/weather?q=metro&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 905846 and City name: Mpika
    http://api.openweathermap.org/data/2.5/weather?q=mpika&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 95788 and City name: Hit
    http://api.openweathermap.org/data/2.5/weather?q=hit&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 466258 and City name: Yuryevets
    http://api.openweathermap.org/data/2.5/weather?q=yuryevets&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5983720 and City name: Iqaluit
    http://api.openweathermap.org/data/2.5/weather?q=iqaluit&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 5856516 and City name: Ahuimanu
    http://api.openweathermap.org/data/2.5/weather?q=ahuimanu&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2347470 and City name: Miri
    http://api.openweathermap.org/data/2.5/weather?q=miri&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 771158 and City name: Hajnowka
    http://api.openweathermap.org/data/2.5/weather?q=hajnowka&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1490624 and City name: Surgut
    http://api.openweathermap.org/data/2.5/weather?q=surgut&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3031582 and City name: Saint-Augustin
    http://api.openweathermap.org/data/2.5/weather?q=saint-augustin&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2409663 and City name: Daru
    http://api.openweathermap.org/data/2.5/weather?q=daru&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3460817 and City name: Itambacuri
    http://api.openweathermap.org/data/2.5/weather?q=itambacuri&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3441894 and City name: Maldonado
    http://api.openweathermap.org/data/2.5/weather?q=maldonado&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2449067 and City name: Timbuktu
    http://api.openweathermap.org/data/2.5/weather?q=tombouctou&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3464724 and City name: Diamantino
    http://api.openweathermap.org/data/2.5/weather?q=diamantino&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2940231 and City name: Castrop-Rauxel
    http://api.openweathermap.org/data/2.5/weather?q=castrop-rauxel&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 588365 and City name: Vao
    http://api.openweathermap.org/data/2.5/weather?q=vao&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4033375 and City name: Tevaitoa
    http://api.openweathermap.org/data/2.5/weather?q=tevaitoa&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3372760 and City name: Praia da Vitoria
    http://api.openweathermap.org/data/2.5/weather?q=praia+da+vitoria&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2653755 and City name: Carmarthen
    http://api.openweathermap.org/data/2.5/weather?q=carmarthen&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 525719 and City name: Mokrous
    http://api.openweathermap.org/data/2.5/weather?q=mokrous&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2646088 and City name: Inverness
    http://api.openweathermap.org/data/2.5/weather?q=inverness&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1633070 and City name: Palembang
    http://api.openweathermap.org/data/2.5/weather?q=palembang&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2179825 and City name: Waitati
    http://api.openweathermap.org/data/2.5/weather?q=waitati&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2186111 and City name: Ngunguru
    http://api.openweathermap.org/data/2.5/weather?q=ngunguru&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2016205 and City name: Sotnikovo
    http://api.openweathermap.org/data/2.5/weather?q=sotnikovo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3429594 and City name: Reconquista
    http://api.openweathermap.org/data/2.5/weather?q=reconquista&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 535839 and City name: Leshukonskoye
    http://api.openweathermap.org/data/2.5/weather?q=leshukonskoye&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2191562 and City name: Dunedin
    http://api.openweathermap.org/data/2.5/weather?q=dunedin&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2126785 and City name: Belaya Gora
    http://api.openweathermap.org/data/2.5/weather?q=belaya+gora&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5882953 and City name: Aklavik
    http://api.openweathermap.org/data/2.5/weather?q=aklavik&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4267710 and City name: Sitka
    http://api.openweathermap.org/data/2.5/weather?q=sitka&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 3533462 and City name: Acapulco
    http://api.openweathermap.org/data/2.5/weather?q=acapulco&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2214433 and City name: Nalut
    http://api.openweathermap.org/data/2.5/weather?q=nalut&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 554199 and City name: Kalininsk
    http://api.openweathermap.org/data/2.5/weather?q=kalininsk&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2088122 and City name: Port Moresby
    http://api.openweathermap.org/data/2.5/weather?q=port+moresby&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6355222 and City name: Yulara
    http://api.openweathermap.org/data/2.5/weather?q=yulara&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4000900 and City name: La Paz
    http://api.openweathermap.org/data/2.5/weather?q=la+paz&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 1850144 and City name: Nishihara
    http://api.openweathermap.org/data/2.5/weather?q=nishihara&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1513983 and City name: Vangazi
    http://api.openweathermap.org/data/2.5/weather?q=vangazi&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3354071 and City name: Oranjemund
    http://api.openweathermap.org/data/2.5/weather?q=oranjemund&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2161515 and City name: Kiama
    http://api.openweathermap.org/data/2.5/weather?q=kiama&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 3834601 and City name: Tartagal
    http://api.openweathermap.org/data/2.5/weather?q=tartagal&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 286245 and City name: Sur
    http://api.openweathermap.org/data/2.5/weather?q=sur&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2396518 and City name: Port-Gentil
    http://api.openweathermap.org/data/2.5/weather?q=port-gentil&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6620339 and City name: Karratha
    http://api.openweathermap.org/data/2.5/weather?q=karratha&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2122389 and City name: Ossora
    http://api.openweathermap.org/data/2.5/weather?q=ossora&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2013921 and City name: Ust-Kuyga
    http://api.openweathermap.org/data/2.5/weather?q=ust-kuyga&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    Missing data. Skipping!!!
    Missing data. Skipping!!!
    City id: 1039536 and City name: Maxixe
    http://api.openweathermap.org/data/2.5/weather?q=maxixe&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3948642 and City name: Matara
    http://api.openweathermap.org/data/2.5/weather?q=matara&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 581228 and City name: Arbazh
    http://api.openweathermap.org/data/2.5/weather?q=arbazh&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1501460 and City name: Kulunda
    http://api.openweathermap.org/data/2.5/weather?q=kulunda&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2690170 and City name: Nassjo
    http://api.openweathermap.org/data/2.5/weather?q=nassjo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2467813 and City name: Rafraf
    http://api.openweathermap.org/data/2.5/weather?q=rafraf&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4671240 and City name: Estelle
    http://api.openweathermap.org/data/2.5/weather?q=estelle&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5577158 and City name: Fort Morgan
    http://api.openweathermap.org/data/2.5/weather?q=fort+morgan&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 344979 and City name: Lebu
    http://api.openweathermap.org/data/2.5/weather?q=lebu&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 3347353 and City name: Menongue
    http://api.openweathermap.org/data/2.5/weather?q=menongue&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6145890 and City name: Shelburne
    http://api.openweathermap.org/data/2.5/weather?q=shelburne&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2013279 and City name: Vostok
    http://api.openweathermap.org/data/2.5/weather?q=vostok&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3472609 and City name: Alem Paraiba
    http://api.openweathermap.org/data/2.5/weather?q=alem+paraiba&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3832791 and City name: Villa Carlos Paz
    http://api.openweathermap.org/data/2.5/weather?q=villa+carlos+paz&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3934055 and City name: Chilca
    http://api.openweathermap.org/data/2.5/weather?q=chilca&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1540711 and City name: Muravlenko
    http://api.openweathermap.org/data/2.5/weather?q=muravlenko&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 287832 and City name: Ibra
    http://api.openweathermap.org/data/2.5/weather?q=ibra&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2660718 and City name: Fribourg
    http://api.openweathermap.org/data/2.5/weather?q=fribourg&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4231997 and City name: Avera
    http://api.openweathermap.org/data/2.5/weather?q=avera&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6089245 and City name: Norman Wells
    http://api.openweathermap.org/data/2.5/weather?q=norman+wells&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3466165 and City name: Cidreira
    http://api.openweathermap.org/data/2.5/weather?q=cidreira&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2965139 and City name: Mahon
    http://api.openweathermap.org/data/2.5/weather?q=mahon&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5841207 and City name: Torrington
    http://api.openweathermap.org/data/2.5/weather?q=torrington&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 528109 and City name: Mednogorsk
    http://api.openweathermap.org/data/2.5/weather?q=mednogorsk&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1283679 and City name: Banepa
    http://api.openweathermap.org/data/2.5/weather?q=banepa&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3451138 and City name: Rio Grande
    http://api.openweathermap.org/data/2.5/weather?q=rio+grande&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2027296 and City name: Aykhal
    http://api.openweathermap.org/data/2.5/weather?q=aykhal&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3356832 and City name: Henties Bay
    http://api.openweathermap.org/data/2.5/weather?q=henties+bay&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2109528 and City name: Buala
    http://api.openweathermap.org/data/2.5/weather?q=buala&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2654970 and City name: Brae
    http://api.openweathermap.org/data/2.5/weather?q=brae&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6014443 and City name: Lac du Bonnet
    http://api.openweathermap.org/data/2.5/weather?q=lac+du+bonnet&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1274119 and City name: Chiplun
    http://api.openweathermap.org/data/2.5/weather?q=chiplun&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2338660 and City name: Yaan
    http://api.openweathermap.org/data/2.5/weather?q=yaan&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2541479 and City name: Nador
    http://api.openweathermap.org/data/2.5/weather?q=nador&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 5404476 and City name: Ukiah
    http://api.openweathermap.org/data/2.5/weather?q=ukiah&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1673820 and City name: Kaohsiung
    http://api.openweathermap.org/data/2.5/weather?q=kaohsiung&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2640416 and City name: Sandwick
    http://api.openweathermap.org/data/2.5/weather?q=sandwick&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3355624 and City name: Maltahohe
    http://api.openweathermap.org/data/2.5/weather?q=maltahohe&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 715888 and City name: Sarkad
    http://api.openweathermap.org/data/2.5/weather?q=sarkad&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    Missing data. Skipping!!!
    Missing data. Skipping!!!
    City id: 525426 and City name: Sobolevo
    http://api.openweathermap.org/data/2.5/weather?q=sobolevo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5949563 and City name: Esterhazy
    http://api.openweathermap.org/data/2.5/weather?q=esterhazy&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4673425 and City name: Belton
    http://api.openweathermap.org/data/2.5/weather?q=belton&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1082243 and City name: Ambilobe
    http://api.openweathermap.org/data/2.5/weather?q=ambilobe&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3037899 and City name: Ambon
    http://api.openweathermap.org/data/2.5/weather?q=ambon&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2281120 and City name: Tabou
    http://api.openweathermap.org/data/2.5/weather?q=tabou&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2021031 and City name: Kyren
    http://api.openweathermap.org/data/2.5/weather?q=kyren&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3453439 and City name: Ponta do Sol
    http://api.openweathermap.org/data/2.5/weather?q=ponta+do+sol&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3415212 and City name: Kopavogur
    http://api.openweathermap.org/data/2.5/weather?q=kopavogur&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1510689 and City name: Baykit
    http://api.openweathermap.org/data/2.5/weather?q=baykit&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3121070 and City name: Guadalajara
    http://api.openweathermap.org/data/2.5/weather?q=guadalajara&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 1259385 and City name: Port Blair
    http://api.openweathermap.org/data/2.5/weather?q=port+blair&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3395458 and City name: Maragogi
    http://api.openweathermap.org/data/2.5/weather?q=maragogi&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 926308 and City name: Monkey Bay
    http://api.openweathermap.org/data/2.5/weather?q=monkey+bay&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3442206 and City name: Juan Lacaze
    http://api.openweathermap.org/data/2.5/weather?q=juan+lacaze&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6180550 and City name: Whitehorse
    http://api.openweathermap.org/data/2.5/weather?q=whitehorse&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3653523 and City name: Palora
    http://api.openweathermap.org/data/2.5/weather?q=palora&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2014369 and City name: Ulety
    http://api.openweathermap.org/data/2.5/weather?q=ulety&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5960603 and City name: Geraldton
    http://api.openweathermap.org/data/2.5/weather?q=geraldton&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6068416 and City name: Mayo
    http://api.openweathermap.org/data/2.5/weather?q=mayo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2508813 and City name: Adrar
    http://api.openweathermap.org/data/2.5/weather?q=adrar&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2337542 and City name: Naze
    http://api.openweathermap.org/data/2.5/weather?q=naze&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1106643 and City name: Quatre Cocos
    http://api.openweathermap.org/data/2.5/weather?q=quatre+cocos&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1521379 and City name: Lenger
    http://api.openweathermap.org/data/2.5/weather?q=lenger&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4004616 and City name: Huejuquilla el Alto
    http://api.openweathermap.org/data/2.5/weather?q=huejuquilla+el+alto&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6541934 and City name: Termoli
    http://api.openweathermap.org/data/2.5/weather?q=termoli&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1337610 and City name: Thinadhoo
    http://api.openweathermap.org/data/2.5/weather?q=thinadhoo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1852357 and City name: Shimoda
    http://api.openweathermap.org/data/2.5/weather?q=shimoda&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 786562 and City name: Dukat
    http://api.openweathermap.org/data/2.5/weather?q=dukat&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 359796 and City name: Suez
    http://api.openweathermap.org/data/2.5/weather?q=suez&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3994912 and City name: Nochistlan
    http://api.openweathermap.org/data/2.5/weather?q=nochistlan&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4034551 and City name: Faanui
    http://api.openweathermap.org/data/2.5/weather?q=faanui&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4513805 and City name: Harrison
    http://api.openweathermap.org/data/2.5/weather?q=harrison&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3421719 and City name: Narsaq
    http://api.openweathermap.org/data/2.5/weather?q=narsaq&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1640902 and City name: Kawalu
    http://api.openweathermap.org/data/2.5/weather?q=kawalu&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3932145 and City name: Pisco
    http://api.openweathermap.org/data/2.5/weather?q=pisco&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5866063 and City name: Kenai
    http://api.openweathermap.org/data/2.5/weather?q=kenai&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2123814 and City name: Leningradskiy
    http://api.openweathermap.org/data/2.5/weather?q=leningradskiy&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1526038 and City name: Atbasar
    http://api.openweathermap.org/data/2.5/weather?q=atbasar&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6050066 and City name: La Ronge
    http://api.openweathermap.org/data/2.5/weather?q=la+ronge&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1645528 and City name: Denpasar
    http://api.openweathermap.org/data/2.5/weather?q=denpasar&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3421193 and City name: Paamiut
    http://api.openweathermap.org/data/2.5/weather?q=paamiut&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 504187 and City name: Puksoozero
    http://api.openweathermap.org/data/2.5/weather?q=puksoozero&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3894426 and City name: Coihaique
    http://api.openweathermap.org/data/2.5/weather?q=coihaique&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3652758 and City name: Puerto Baquerizo Moreno
    http://api.openweathermap.org/data/2.5/weather?q=puerto+baquerizo+moreno&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2068110 and City name: Kununurra
    http://api.openweathermap.org/data/2.5/weather?q=kununurra&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2014624 and City name: Udachnyy
    http://api.openweathermap.org/data/2.5/weather?q=udachnyy&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2278158 and City name: Buchanan
    http://api.openweathermap.org/data/2.5/weather?q=buchanan&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1508517 and City name: Bystryy Istok
    http://api.openweathermap.org/data/2.5/weather?q=bystryy+istok&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2448085 and City name: Agadez
    http://api.openweathermap.org/data/2.5/weather?q=agadez&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1071296 and City name: Antalaha
    http://api.openweathermap.org/data/2.5/weather?q=antalaha&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3617154 and City name: Puerto Cabezas
    http://api.openweathermap.org/data/2.5/weather?q=puerto+cabezas&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1083724 and City name: Ambanja
    http://api.openweathermap.org/data/2.5/weather?q=ambanja&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3662395 and City name: Santo Antonio do Ica
    http://api.openweathermap.org/data/2.5/weather?q=santo+antonio+do+ica&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1498314 and City name: Motygino
    http://api.openweathermap.org/data/2.5/weather?q=motygino&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4372777 and City name: Vardo
    http://api.openweathermap.org/data/2.5/weather?q=vardo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3347019 and City name: Namibe
    http://api.openweathermap.org/data/2.5/weather?q=namibe&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 246008 and City name: Wadi Musa
    http://api.openweathermap.org/data/2.5/weather?q=wadi+musa&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2304548 and City name: Anloga
    http://api.openweathermap.org/data/2.5/weather?q=anloga&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2737599 and City name: Saldanha
    http://api.openweathermap.org/data/2.5/weather?q=saldanha&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 141665 and City name: Bandar-e Lengeh
    http://api.openweathermap.org/data/2.5/weather?q=bandar-e+lengeh&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1253220 and City name: Vetapalem
    http://api.openweathermap.org/data/2.5/weather?q=vetapalem&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 161616 and City name: Balkanabat
    http://api.openweathermap.org/data/2.5/weather?q=balkanabat&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 3685702 and City name: Cravo Norte
    http://api.openweathermap.org/data/2.5/weather?q=cravo+norte&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3661980 and City name: Tarauaca
    http://api.openweathermap.org/data/2.5/weather?q=tarauaca&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1685422 and City name: Sulangan
    http://api.openweathermap.org/data/2.5/weather?q=sulangan&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 545982 and City name: Kolyshley
    http://api.openweathermap.org/data/2.5/weather?q=kolyshley&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 4013704 and City name: Laguna
    http://api.openweathermap.org/data/2.5/weather?q=laguna&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2155562 and City name: Nelson Bay
    http://api.openweathermap.org/data/2.5/weather?q=nelson+bay&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 110690 and City name: Abha
    http://api.openweathermap.org/data/2.5/weather?q=abha&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1505965 and City name: Igrim
    http://api.openweathermap.org/data/2.5/weather?q=igrim&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2194098 and City name: Ahipara
    http://api.openweathermap.org/data/2.5/weather?q=ahipara&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2127202 and City name: Anadyr
    http://api.openweathermap.org/data/2.5/weather?q=anadyr&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 531426 and City name: Malaya Purga
    http://api.openweathermap.org/data/2.5/weather?q=malaya+purga&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3404558 and City name: Cabedelo
    http://api.openweathermap.org/data/2.5/weather?q=cabedelo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3374120 and City name: Vila do Maio
    http://api.openweathermap.org/data/2.5/weather?q=vila+do+maio&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2121025 and City name: Srednekolymsk
    http://api.openweathermap.org/data/2.5/weather?q=srednekolymsk&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 164947 and City name: Salamiyah
    http://api.openweathermap.org/data/2.5/weather?q=salamiyah&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2126710 and City name: Beringovskiy
    http://api.openweathermap.org/data/2.5/weather?q=beringovskiy&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1106677 and City name: Bambous Virieux
    http://api.openweathermap.org/data/2.5/weather?q=bambous+virieux&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2413070 and City name: Nioro
    http://api.openweathermap.org/data/2.5/weather?q=nioro&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2012956 and City name: Yerbogachen
    http://api.openweathermap.org/data/2.5/weather?q=yerbogachen&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3838859 and City name: Rio Gallegos
    http://api.openweathermap.org/data/2.5/weather?q=rio+gallegos&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4589446 and City name: North Myrtle Beach
    http://api.openweathermap.org/data/2.5/weather?q=north+myrtle+beach&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5563397 and City name: Eureka
    http://api.openweathermap.org/data/2.5/weather?q=eureka&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2032201 and City name: Bulgan
    http://api.openweathermap.org/data/2.5/weather?q=bulgan&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1651103 and City name: Atambua
    http://api.openweathermap.org/data/2.5/weather?q=atambua&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3439189 and City name: Capitan Bado
    http://api.openweathermap.org/data/2.5/weather?q=capitan+bado&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2160063 and City name: Codrington
    http://api.openweathermap.org/data/2.5/weather?q=codrington&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3998214 and City name: Obregon
    http://api.openweathermap.org/data/2.5/weather?q=obregon&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2449893 and City name: Tessalit
    http://api.openweathermap.org/data/2.5/weather?q=tessalit&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2422465 and City name: Conakry
    http://api.openweathermap.org/data/2.5/weather?q=conakry&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2012530 and City name: Zhigansk
    http://api.openweathermap.org/data/2.5/weather?q=zhigansk&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1634614 and City name: Nabire
    http://api.openweathermap.org/data/2.5/weather?q=nabire&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4529292 and City name: Altus
    http://api.openweathermap.org/data/2.5/weather?q=altus&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3443061 and City name: Chuy
    http://api.openweathermap.org/data/2.5/weather?q=chuy&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5861897 and City name: Fairbanks
    http://api.openweathermap.org/data/2.5/weather?q=fairbanks&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2377457 and City name: Nouadhibou
    http://api.openweathermap.org/data/2.5/weather?q=nouadhibou&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2179532 and City name: Wellsford
    http://api.openweathermap.org/data/2.5/weather?q=wellsford&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1636544 and City name: Manado
    http://api.openweathermap.org/data/2.5/weather?q=manado&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1501000 and City name: Kyshtovka
    http://api.openweathermap.org/data/2.5/weather?q=kyshtovka&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5554428 and City name: Ketchikan
    http://api.openweathermap.org/data/2.5/weather?q=ketchikan&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 555980 and City name: Ishimbay
    http://api.openweathermap.org/data/2.5/weather?q=ishimbay&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1728091 and City name: Balingasay
    http://api.openweathermap.org/data/2.5/weather?q=balingasay&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2122104 and City name: Petropavlovsk-Kamchatskiy
    http://api.openweathermap.org/data/2.5/weather?q=petropavlovsk-kamchatskiy&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1254709 and City name: Tezu
    http://api.openweathermap.org/data/2.5/weather?q=tezu&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 779622 and City name: Havoysund
    http://api.openweathermap.org/data/2.5/weather?q=havoysund&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2138285 and City name: Tadine
    http://api.openweathermap.org/data/2.5/weather?q=tadine&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3126369 and City name: Carballo
    http://api.openweathermap.org/data/2.5/weather?q=carballo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1856392 and City name: Muroto
    http://api.openweathermap.org/data/2.5/weather?q=muroto&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 53654 and City name: Mogadishu
    http://api.openweathermap.org/data/2.5/weather?q=mogadishu&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2487130 and City name: Sidi Ali
    http://api.openweathermap.org/data/2.5/weather?q=sidi+ali&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1314759 and City name: Lashio
    http://api.openweathermap.org/data/2.5/weather?q=lashio&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3662342 and City name: Sao Gabriel da Cachoeira
    http://api.openweathermap.org/data/2.5/weather?q=sao+gabriel+da+cachoeira&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1642773 and City name: Japura
    http://api.openweathermap.org/data/2.5/weather?q=japura&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1266928 and City name: Khargone
    http://api.openweathermap.org/data/2.5/weather?q=khargone&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2267254 and City name: Lagoa
    http://api.openweathermap.org/data/2.5/weather?q=lagoa&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2022369 and City name: Kholtoson
    http://api.openweathermap.org/data/2.5/weather?q=kholtoson&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3386213 and City name: Touros
    http://api.openweathermap.org/data/2.5/weather?q=touros&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1045114 and City name: Inhambane
    http://api.openweathermap.org/data/2.5/weather?q=inhambane&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1636022 and City name: Martapura
    http://api.openweathermap.org/data/2.5/weather?q=martapura&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 3530097 and City name: Champerico
    http://api.openweathermap.org/data/2.5/weather?q=champerico&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3037456 and City name: Saint-Joseph
    http://api.openweathermap.org/data/2.5/weather?q=saint-joseph&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3472284 and City name: Anastacio
    http://api.openweathermap.org/data/2.5/weather?q=anastacio&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2027042 and City name: Batagay-Alyta
    http://api.openweathermap.org/data/2.5/weather?q=batagay-alyta&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2633414 and City name: Yarmouth
    http://api.openweathermap.org/data/2.5/weather?q=yarmouth&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2021017 and City name: Kysyl-Syr
    http://api.openweathermap.org/data/2.5/weather?q=kysyl-syr&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3468352 and City name: Cacu
    http://api.openweathermap.org/data/2.5/weather?q=cacu&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1264976 and City name: Leh
    http://api.openweathermap.org/data/2.5/weather?q=leh&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3420768 and City name: Qasigiannguit
    http://api.openweathermap.org/data/2.5/weather?q=qasigiannguit&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1643837 and City name: Gorontalo
    http://api.openweathermap.org/data/2.5/weather?q=gorontalo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2063030 and City name: Port Pirie
    http://api.openweathermap.org/data/2.5/weather?q=port+pirie&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3516078 and City name: Tekanto
    http://api.openweathermap.org/data/2.5/weather?q=tekanto&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2033225 and City name: Zalantun
    http://api.openweathermap.org/data/2.5/weather?q=zalantun&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 584051 and City name: Svetlogorsk
    http://api.openweathermap.org/data/2.5/weather?q=svetlogorsk&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 467252 and City name: Yermish
    http://api.openweathermap.org/data/2.5/weather?q=yermish&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5847486 and City name: Kailua
    http://api.openweathermap.org/data/2.5/weather?q=kailua&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1170395 and City name: Mingaora
    http://api.openweathermap.org/data/2.5/weather?q=mingaora&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2669047 and City name: Timra
    http://api.openweathermap.org/data/2.5/weather?q=timra&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2448442 and City name: Yorosso
    http://api.openweathermap.org/data/2.5/weather?q=yorosso&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2282006 and City name: San-Pedro
    http://api.openweathermap.org/data/2.5/weather?q=san-pedro&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2126682 and City name: Bilibino
    http://api.openweathermap.org/data/2.5/weather?q=bilibino&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1650064 and City name: Barabai
    http://api.openweathermap.org/data/2.5/weather?q=barabai&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4033077 and City name: Vaitape
    http://api.openweathermap.org/data/2.5/weather?q=vaitape&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 467527 and City name: Yemtsa
    http://api.openweathermap.org/data/2.5/weather?q=yemtsa&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2261577 and City name: Vila Vicosa
    http://api.openweathermap.org/data/2.5/weather?q=vila+vicosa&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 197745 and City name: Garissa
    http://api.openweathermap.org/data/2.5/weather?q=garissa&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 215771 and City name: Isiro
    http://api.openweathermap.org/data/2.5/weather?q=isiro&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5193309 and City name: Hermitage
    http://api.openweathermap.org/data/2.5/weather?q=hermitage&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4243951 and City name: Marshall
    http://api.openweathermap.org/data/2.5/weather?q=marshall&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2618795 and City name: Klaksvik
    http://api.openweathermap.org/data/2.5/weather?q=klaksvik&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3665202 and City name: Aripuana
    http://api.openweathermap.org/data/2.5/weather?q=aripuana&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3420846 and City name: Qaqortoq
    http://api.openweathermap.org/data/2.5/weather?q=qaqortoq&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1493162 and City name: Salym
    http://api.openweathermap.org/data/2.5/weather?q=salym&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3430443 and City name: Necochea
    http://api.openweathermap.org/data/2.5/weather?q=necochea&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5746545 and City name: Portland
    http://api.openweathermap.org/data/2.5/weather?q=portland&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6324729 and City name: Halifax
    http://api.openweathermap.org/data/2.5/weather?q=halifax&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1684803 and City name: Tabuk
    http://api.openweathermap.org/data/2.5/weather?q=tabuk&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3652462 and City name: San Cristobal
    http://api.openweathermap.org/data/2.5/weather?q=san+cristobal&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3397909 and City name: Itapipoca
    http://api.openweathermap.org/data/2.5/weather?q=itapipoca&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1072879 and City name: Ankazoabo
    http://api.openweathermap.org/data/2.5/weather?q=ankazoabo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 592062 and City name: Iisaku
    http://api.openweathermap.org/data/2.5/weather?q=iisaku&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 1065158 and City name: Farafangana
    http://api.openweathermap.org/data/2.5/weather?q=farafangana&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5962442 and City name: Goderich
    http://api.openweathermap.org/data/2.5/weather?q=goderich&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3577154 and City name: Oranjestad
    http://api.openweathermap.org/data/2.5/weather?q=oranjestad&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3897774 and City name: Buin
    http://api.openweathermap.org/data/2.5/weather?q=buin&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 1222222 and City name: Ayni
    http://api.openweathermap.org/data/2.5/weather?q=ayni&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3711668 and City name: Jimenez
    http://api.openweathermap.org/data/2.5/weather?q=jimenez&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 8014555 and City name: Charneca de Caparica
    http://api.openweathermap.org/data/2.5/weather?q=charneca+de+caparica&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1794971 and City name: Shitanjing
    http://api.openweathermap.org/data/2.5/weather?q=shitanjing&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    Missing data. Skipping!!!
    City id: 565857 and City name: Dobrinka
    http://api.openweathermap.org/data/2.5/weather?q=dobrinka&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1795095 and City name: Mingshui
    http://api.openweathermap.org/data/2.5/weather?q=mingshui&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1261517 and City name: Nepa Nagar
    http://api.openweathermap.org/data/2.5/weather?q=nepa+nagar&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3664980 and City name: Boa Vista
    http://api.openweathermap.org/data/2.5/weather?q=boa+vista&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1687186 and City name: Sarangani
    http://api.openweathermap.org/data/2.5/weather?q=sarangani&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4712933 and City name: Mount Pleasant
    http://api.openweathermap.org/data/2.5/weather?q=mount+pleasant&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2063042 and City name: Port Hedland
    http://api.openweathermap.org/data/2.5/weather?q=port+hedland&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2446796 and City name: Bilma
    http://api.openweathermap.org/data/2.5/weather?q=bilma&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3622751 and City name: Naranjo
    http://api.openweathermap.org/data/2.5/weather?q=naranjo&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2018735 and City name: Nyurba
    http://api.openweathermap.org/data/2.5/weather?q=nyurba&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    Missing data. Skipping!!!
    City id: 2319133 and City name: Adeje
    http://api.openweathermap.org/data/2.5/weather?q=adeje&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3402648 and City name: Carutapera
    http://api.openweathermap.org/data/2.5/weather?q=carutapera&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6050610 and City name: Laval
    http://api.openweathermap.org/data/2.5/weather?q=laval&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2227402 and City name: Meiganga
    http://api.openweathermap.org/data/2.5/weather?q=meiganga&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3014727 and City name: Batie
    http://api.openweathermap.org/data/2.5/weather?q=batie&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 187968 and City name: Malindi
    http://api.openweathermap.org/data/2.5/weather?q=malindi&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3355672 and City name: Luderitz
    http://api.openweathermap.org/data/2.5/weather?q=luderitz&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 581357 and City name: Apatity
    http://api.openweathermap.org/data/2.5/weather?q=apatity&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1090415 and City name: Chirongui
    http://api.openweathermap.org/data/2.5/weather?q=chirongui&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2152659 and City name: Port Macquarie
    http://api.openweathermap.org/data/2.5/weather?q=port+macquarie&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1264489 and City name: Mahad
    http://api.openweathermap.org/data/2.5/weather?q=mahad&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3460954 and City name: Praia
    http://api.openweathermap.org/data/2.5/weather?q=praia&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2120591 and City name: Tilichiki
    http://api.openweathermap.org/data/2.5/weather?q=tilichiki&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 87205 and City name: Darnah
    http://api.openweathermap.org/data/2.5/weather?q=darnah&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 553725 and City name: Kamenka
    http://api.openweathermap.org/data/2.5/weather?q=kamenka&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4787534 and City name: Sterling
    http://api.openweathermap.org/data/2.5/weather?q=sterling&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4732862 and City name: Nome
    http://api.openweathermap.org/data/2.5/weather?q=nome&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 350203 and City name: Rosetta
    http://api.openweathermap.org/data/2.5/weather?q=rosetta&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5374920 and City name: Morro Bay
    http://api.openweathermap.org/data/2.5/weather?q=morro+bay&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 710342 and City name: Chutove
    http://api.openweathermap.org/data/2.5/weather?q=chutove&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4174855 and City name: Tarpon Springs
    http://api.openweathermap.org/data/2.5/weather?q=tarpon+springs&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2145110 and City name: Wagga Wagga
    http://api.openweathermap.org/data/2.5/weather?q=wagga+wagga&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 5935341 and City name: Dauphin
    http://api.openweathermap.org/data/2.5/weather?q=dauphin&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2090021 and City name: Namatanai
    http://api.openweathermap.org/data/2.5/weather?q=namatanai&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1650434 and City name: Bambanglipuro
    http://api.openweathermap.org/data/2.5/weather?q=bambanglipuro&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4863349 and City name: Basco
    http://api.openweathermap.org/data/2.5/weather?q=basco&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 570455 and City name: Buzdyak
    http://api.openweathermap.org/data/2.5/weather?q=buzdyak&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4034438 and City name: Haapiti
    http://api.openweathermap.org/data/2.5/weather?q=haapiti&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2641598 and City name: Newport
    http://api.openweathermap.org/data/2.5/weather?q=newport&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 561698 and City name: Gayny
    http://api.openweathermap.org/data/2.5/weather?q=gayny&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1253628 and City name: Lata
    http://api.openweathermap.org/data/2.5/weather?q=lata&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3868707 and City name: Valdivia
    http://api.openweathermap.org/data/2.5/weather?q=valdivia&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1490796 and City name: Strezhevoy
    http://api.openweathermap.org/data/2.5/weather?q=strezhevoy&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6541257 and City name: Monopoli
    http://api.openweathermap.org/data/2.5/weather?q=monopoli&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2447513 and City name: Arlit
    http://api.openweathermap.org/data/2.5/weather?q=arlit&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4723422 and City name: Rockport
    http://api.openweathermap.org/data/2.5/weather?q=rockport&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 6255012 and City name: Flinders
    http://api.openweathermap.org/data/2.5/weather?q=flinders&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 737021 and City name: Zonguldak
    http://api.openweathermap.org/data/2.5/weather?q=zonguldak&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 1538641 and City name: Kedrovyy
    http://api.openweathermap.org/data/2.5/weather?q=kedrovyy&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 105299 and City name: Jizan
    http://api.openweathermap.org/data/2.5/weather?q=jizan&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 4435764 and City name: Meridian
    http://api.openweathermap.org/data/2.5/weather?q=meridian&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 2656847 and City name: Atherton
    http://api.openweathermap.org/data/2.5/weather?q=atherton&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    City id: 3645527 and City name: Ciudad Ojeda
    http://api.openweathermap.org/data/2.5/weather?q=ciudad+ojeda&units=IMPERIAL&mode=json&APPID=8f1b9cd4a84af0404d4d40da7aa2636c
    




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>City</th>
      <th>Country</th>
      <th>Latitude</th>
      <th>Temperature</th>
      <th>Humidity</th>
      <th>Cloud Cover</th>
      <th>Wind Speed</th>
      <th>Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>&lt;citipy.citipy.City object at 0x000002075FF7CBE0&gt;</td>
      <td>qaanaaq</td>
      <td>gl</td>
      <td>77.48</td>
      <td>-20.62</td>
      <td>58.0</td>
      <td>48.0</td>
      <td>5.95</td>
      <td>1521786662</td>
    </tr>
    <tr>
      <th>1</th>
      <td>&lt;citipy.citipy.City object at 0x0000020760680400&gt;</td>
      <td>taoudenni</td>
      <td>ml</td>
      <td>22.68</td>
      <td>45.99</td>
      <td>30.0</td>
      <td>0.0</td>
      <td>8.41</td>
      <td>1521786679</td>
    </tr>
    <tr>
      <th>2</th>
      <td>&lt;citipy.citipy.City object at 0x00000207615B3390&gt;</td>
      <td>richards bay</td>
      <td>za</td>
      <td>-28.77</td>
      <td>65.61</td>
      <td>100.0</td>
      <td>92.0</td>
      <td>5.17</td>
      <td>1521786741</td>
    </tr>
    <tr>
      <th>3</th>
      <td>&lt;citipy.citipy.City object at 0x00000207615A0FD0&gt;</td>
      <td>bredasdorp</td>
      <td>za</td>
      <td>-34.53</td>
      <td>63.00</td>
      <td>98.0</td>
      <td>0.0</td>
      <td>13.22</td>
      <td>1521786670</td>
    </tr>
    <tr>
      <th>4</th>
      <td>&lt;citipy.citipy.City object at 0x000002075FA45128&gt;</td>
      <td>liniere</td>
      <td>ca</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.00</td>
      <td></td>
    </tr>
  </tbody>
</table>
</div>




```python
print(json.dumps(weather, indent=4, sort_keys=True))
```

    {
        "base": "stations",
        "clouds": {
            "all": 68
        },
        "cod": 200,
        "coord": {
            "lat": 10.22,
            "lon": -71.33
        },
        "dt": 1521787203,
        "id": 3645527,
        "main": {
            "grnd_level": 1020.14,
            "humidity": 90,
            "pressure": 1020.14,
            "sea_level": 1022.52,
            "temp": 82.89,
            "temp_max": 82.89,
            "temp_min": 82.89
        },
        "name": "Ciudad Ojeda",
        "sys": {
            "country": "VE",
            "message": 0.005,
            "sunrise": 1521802053,
            "sunset": 1521845763
        },
        "weather": [
            {
                "description": "broken clouds",
                "icon": "04n",
                "id": 803,
                "main": "Clouds"
            }
        ],
        "wind": {
            "deg": 323.503,
            "speed": 6.85
        }
    }
    


```python
# Save our Cities DataFrame as csv file
cities_df.to_csv("equatorial_cities.csv", encoding="utf-8", index=False)
```


```python
cities_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>City</th>
      <th>Country</th>
      <th>Latitude</th>
      <th>Temperature</th>
      <th>Humidity</th>
      <th>Cloud Cover</th>
      <th>Wind Speed</th>
      <th>Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>&lt;citipy.citipy.City object at 0x000002075FF7CBE0&gt;</td>
      <td>qaanaaq</td>
      <td>gl</td>
      <td>77.48</td>
      <td>-20.62</td>
      <td>58</td>
      <td>48</td>
      <td>5.95</td>
      <td>1521786662</td>
    </tr>
    <tr>
      <th>1</th>
      <td>&lt;citipy.citipy.City object at 0x0000020760680400&gt;</td>
      <td>taoudenni</td>
      <td>ml</td>
      <td>22.68</td>
      <td>45.99</td>
      <td>30</td>
      <td>0</td>
      <td>8.41</td>
      <td>1521786679</td>
    </tr>
    <tr>
      <th>2</th>
      <td>&lt;citipy.citipy.City object at 0x00000207615B3390&gt;</td>
      <td>richards bay</td>
      <td>za</td>
      <td>-28.77</td>
      <td>65.61</td>
      <td>100</td>
      <td>92</td>
      <td>5.17</td>
      <td>1521786741</td>
    </tr>
    <tr>
      <th>3</th>
      <td>&lt;citipy.citipy.City object at 0x00000207615A0FD0&gt;</td>
      <td>bredasdorp</td>
      <td>za</td>
      <td>-34.53</td>
      <td>63</td>
      <td>98</td>
      <td>0</td>
      <td>13.22</td>
      <td>1521786670</td>
    </tr>
    <tr>
      <th>4</th>
      <td>&lt;citipy.citipy.City object at 0x000002075FA45128&gt;</td>
      <td>liniere</td>
      <td>ca</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  </tbody>
</table>
</div>




```python
cities_df.dtypes
```




    0              object
    City           object
    Country        object
    Latitude       object
    Temperature    object
    Humidity       object
    Cloud Cover    object
    Wind Speed     object
    Date           object
    dtype: object




```python
cities_df[['Latitude','Temperature', 'Humidity', 'Cloud Cover', 'Wind Speed']] = cities_df[['Latitude','Temperature', 'Humidity', 'Cloud Cover', 'Wind Speed']].apply(pd.to_numeric)
```


```python
cities_df.dtypes
```




    0               object
    City            object
    Country         object
    Latitude       float64
    Temperature    float64
    Humidity       float64
    Cloud Cover    float64
    Wind Speed     float64
    Date            object
    dtype: object




```python
# Build a scatter plot for each data type

cities_df.plot(x ='Latitude', y='Temperature', style='o')

# Incorporate the other graph properties
plt.title("Temerature (F) vs. Latitude")
plt.ylabel("Temperature (F)")
plt.xlabel("Latitude")
plt.grid(True)
plt.xlim([-90, 90])
plt.ylim([-100,150])

# Save the figure
plt.savefig("Temperature-Lattitude.png")

# Show plot
plt.show()


```


![png](output_16_0.png)



```python
cities_df.plot(x ='Latitude', y ='Humidity', style='o')

# Incorporate the other graph properties
plt.title("Humidity (%) vs. Latitude")
plt.ylabel("Humidity (%)")
plt.xlabel("Latitude")
plt.grid(True)
plt.xlim([-90, 90])
plt.ylim([0,100])

# Save the figure
plt.savefig("Humidity-Latitude.png")

# Show plot
plt.show()

```


![png](output_17_0.png)



```python
cities_df.plot(x ='Latitude', y ='Cloud Cover', style='o')

# Incorporate the other graph properties
plt.title("Cloudiness (%) vs. Latitude")
plt.ylabel("Cloudiness (%)")
plt.xlabel("Latitude")
plt.grid(True)
plt.xlim([-90, 90])
plt.ylim([-10,100])

# Save the figure
plt.savefig("Cloudiness-Latitude.png")

# Show plot
plt.show()

```


![png](output_18_0.png)



```python
cities_df.plot(x ='Latitude', y ='Wind Speed', style='o')

# Incorporate the other graph properties
plt.title("Wind Speed (mph) vs. Latitude")
plt.ylabel("Wind Speed (mph)")
plt.xlabel("Latitude")
plt.grid(True)
plt.xlim([-90, 90])
plt.ylim([-10,60])

# Save the figure
plt.savefig("WindSpeed-Latitude.png")

# Show plot
plt.show()

```


![png](output_19_0.png)

